--Readme document for *author*--

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

9/10
- 1/1 Tweet dates
- 1/1 Tweet categories
- 1/1 User-written tweets
- 2/2 Determining activity type and distance
- 2/2 Graphing activities by distance
- 1/1 Implementing the search box
- 1/2 Populating the table

2. How long, in hours, did it take you to complete this assignment?
    about 18 hours


3. What online resources did you consult when completing this assignment? (list sites like StackOverflow or specific URLs for tutorials, etc.)
w3schools.com
https://api.jquery.com/
https://vega.github.io/vega-lite/docs/


4. What classmates or other individuals did you consult as part of this assignment? What did you discuss?
Luis Chavez helped me on slack with event triggers and pointed me to the api documentation
https://uci-inf133-fa19.slack.com/archives/CP5AQV9LZ/p1572504205203900?thread_ts=1572503938.200300&cid=CP5AQV9LZ
https://uci-inf133-fa19.slack.com/archives/CP5AQV9LZ/p1572500685183900



5. Is there anything special we need to know in order to run your code?
search clearing doesnt work fyi

