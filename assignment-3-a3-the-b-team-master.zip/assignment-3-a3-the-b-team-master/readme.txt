--Readme document for Matt Buscemi, mbuscemi@uci.edu, 87517892--

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

9/10
- 1/1 Communicating with the webserver
- 1/1 Populating information about the user
- 3/3 Populating the search component
- 2/2 Artist page
- 1.5/1.5 Album page
- .5/1.5 Track page


2. How long, in hours, did it take you to complete this assignment?
approx 18


3. What online resources did you consult when completing this assignment? (list specific URLs)
https://developer.spotify.com/documentation/web-api/reference/
https://www.w3schools.com/js/default.asp
https://angular.io/guide/http#requesting-data-from-server

https://stackoverflow.com/questions/44944570/using-slice-pipe-with-variable-parameters-in-ngfor




4. What classmates or other individuals did you consult as part of this assignment? What did you discuss?
https://uci-inf133-fa19.slack.com/archives/CPU4XES64/p1574139437355300
https://uci-inf133-fa19.slack.com/archives/CPU4XES64/p1574139408354600
https://uci-inf133-fa19.slack.com/archives/CPU4XES64/p1574138925351600



5. Did you add a bonus feature to your submission? If so, what is it and how should we see it?
no


6. Is there anything special we need to know in order to run your code?
make sure to select track artist or album form the dropdown before searching to get it to work properly
